package org.techtown.myproject2;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

/**
 * Created by YUN on 2017-08-07.
 */

public class BusArriveDatas implements Parcelable, Comparable {
    private String busTime, busNumber;

    public BusArriveDatas(String busTime, String busNumber) {
        this.busTime = busTime;
        this.busNumber = busNumber;
    }

    public BusArriveDatas(Parcel in){
        readFromParcel(in);
    }

    public BusArriveDatas(){
    }

    public String getBusTime() {
        return busTime;
    }

    public void setBusTime(String busTime) {
        this.busTime = busTime;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }

    public int describeContents() {
        // TODO Auto-generated method stub
        return 0;
    }

    public void writeToParcel(Parcel arg0, int arg1) {
        // TODO Auto-generated method stub
        arg0.writeString(busTime);
        arg0.writeString(busNumber);
    }

    private void readFromParcel(Parcel in) {
        // TODO Auto-generated method stub
        busTime = in.readString();
        busNumber = in.readString();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {

        public BusArriveDatas createFromParcel(Parcel source) {
            // TODO Auto-generated method stub
            return new BusArriveDatas(source);
        }

        public BusArriveDatas[] newArray(int size) {
            // TODO Auto-generated method stub
            return new BusArriveDatas[size];
        }
    };

    @Override
    public int compareTo(@NonNull Object o) {
        if(o == null) return 0;

        BusArriveDatas bus = (BusArriveDatas)o;

        if(Integer.parseInt(this.getBusTime()) > Integer.parseInt(bus.getBusTime())) {
            return 1;
        } else if(Integer.parseInt(this.getBusTime()) < Integer.parseInt(bus.getBusTime())) {
            return -1;
        } else {
            return 0;
        }
    }
}
